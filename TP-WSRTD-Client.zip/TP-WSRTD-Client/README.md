# TP-WSRTD-Client

A working implementation of a **Tai Pan → AmiBroker WebSocket bridge** using the WS_RTD plugin.

## Overview

This repository contains two coordinated components:

1. **FeedServer.cs** – C# data source client using the Tai Pan SDK (TPRAccess).
   - Streams real-time quotes as Json-RTD via WebSocket.
   - Serves historical (HIST) backfill requests in 5-day chunks.
   - Provides previous close, day high/low/open, and day volume for each symbol.

2. **BridgeClient.py** – Python bridge (the “client”) that connects between the feed and WS_RTD plugin.
   - Passes RTQ packets directly to AmiBroker.
   - Aggregates raw tick HIST data chronologically into 1-minute bars.
   - Sends symbol metadata (INFO) from a CSV, including alias, full name, ISIN, and market ID.

This setup allows AmiBroker to import symbols and metadata from Tai Pan Euronext feed data, maintain 30 days of backfill per symbol, and trade via IBKR using matching aliases.

## Notes

- Tested with 173 Euronext symbols.
- Requires WS_RTD plugin v7.0+.
- Compatible with Python ≥3.10 and .NET ≥4.7.2.
- PrevClose value is injected manually since it is missing from Tai Pan’s live stream.
